---
layout: default
title: Contact
---
<form action="https://formspree.io/f/your_form_id" method="POST">
  <input type="text" name="name" placeholder="Your Name" required>
  <input type="email" name="_replyto" placeholder="Your Email" required>
  <textarea name="message" placeholder="Message" required></textarea>
  <button type="submit">Send</button>
</form>
