from sqlalchemy import Column, Integer, String, create_engine, ForeignKey
from sqlalchemy.sql.expression import text
from .database import Base

class Student(Base):
    __tablename__ = "Students"
    Name = Column(String, primary_key=True, nullable=False)
    sclass = Column(String, nullable=False)
    section = Column(String, nullable=False)
    
class User(Base):
    __tablename__ = "Users1"
    id = Column(Integer, primary_key=True, nullable=False)
    email = Column(String, nullable=False)
    password = Column(String, nullable=False)