from pydantic import BaseModel
class Student(BaseModel):  
    Name: str
    sclass: str
    section: str
    
class StudentCreate(Student):
    pass

class Stu(Student):
    name: str
    class Config:
        orm_mode = True
        
class UserCreate(BaseModel):
    id: int
    email: str
    password: str
    
class UserOut(BaseModel):
    email: str

class Config:
    orm_modev=True

class Userlogin(BaseModel):
    email: str
    password: str