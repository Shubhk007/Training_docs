from fastapi import FastAPI, HTTPException, Response, Depends
from random import randrange
from typing import Optional
from fastapi.params import Body
from pydantic import BaseModel
from fastapi import status
from sqlalchemy.orm import Session
import sqlite3
from .routers import post
from .routers import users, auth
app = FastAPI()

app.include_router(post.router)
app.include_router(users.router)
app.include_router(auth.router)

from . import Models
from . import Schemas
from .database import engine, get_db

# This line of code creates all the tables in the database based on the models defined in Models.py
# It is using the engine object which is a connection to the database to create the tables
# The create_all method is a part of SQLAlchemy's declarative extension which is used to define the models
# The bind argument is used to specify the engine object which is the connection to the database
# The bind argument is necessary because the models are defined in a separate file and they don't know about the engine object
# By using the bind argument, we are telling SQLAlchemy to use the engine object to create the tables in the database
Models.Base.metadata.create_all(bind=engine)

@app.get("/")
def welcome():
    return {"message": "Welcome to FastAPI...."}


@app.get("/loadAll")
def loadAll(db: Session = Depends(get_db)):
    students = db.query(Models.Student).all()
    return {"data": students}

@app.post("/addSudent", status_code=status.HTTP_201_CREATED)
def addSudent(student: Schemas.Student, db: Session = Depends(get_db)):
    new_student = Models.Student(Name=student.Name, sclass=student.sclass, section=student.section)
    db.add(new_student)
    db.commit()
    db.refresh(new_student)
    return {"message": new_student}

@app.get("/loadStudentByName/{name}")
def getStudentByName(name: str, db: Session = Depends(get_db)):
    student = db.query(Models.Student).filter(Models.Student.Name == name).first()
    if not student:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Student with name {name} not found")
    return {"data": student}

#update & delete
@app.put("/updateStudent/{name}")
def updateStudent(name: str, student: Schemas.Student, db: Session = Depends(get_db)):
    student1 = db.query(Models.Student).filter(Models.Student.Name == name).first()
    student1.Name = student.Name
    student1.sclass = student.sclass
    student1.section = student.section
    db.commit()
    db.refresh(student1)
    return {"message": student1}

@app.delete("/deleteStudent/{name}", status_code=status.HTTP_204_NO_CONTENT)
def deleteStudent(name: str, db: Session = Depends(get_db)):
    student = db.query(Models.Student).filter(Models.Student.Name == name).first()
    if not student:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Student with name {name} not found")
    db.delete(student)
    db.commit()
    return {"message": f"Student with name {name} deleted"}

