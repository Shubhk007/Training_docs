from fastapi import FastAPI, HTTPException, Response, Depends, status, APIRouter
from sqlalchemy.orm import Session
from typing import Optional, List

from .. import Models, Schemas
from .. database import engine, get_db

router = APIRouter(
    tags=["authentication"]
)

@router.post("/login")
def validateUser(user: Schemas.Userlogin, db: Session = Depends(get_db)):
    user = db.query(Models.User).filter(Models.User.email == user.email).first()
    if user ==None:
        return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    else:
        return {"message": "user authenticated"}