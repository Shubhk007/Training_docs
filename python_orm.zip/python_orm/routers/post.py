from fastapi import FastAPI, HTTPException, Response, Depends, status, APIRouter
from sqlalchemy.orm import Session
from typing import Optional, List

from .. import Models, Schemas
from .. database import engine, get_db

router = APIRouter(
    tags=["students"]
)


@router.get("/loadall")
def loadall(db: Session = Depends(get_db)):
    return {"status": "success"}


@router.post("/addstudent", status_code=status.HTTP_201_CREATED,response_model=Schemas.Stu)
def addStudent(student: Schemas.Student, db: Session = Depends(get_db)):
    new_post = Models.Student(**student.dict())
    print(new_post)
    db.add(new_post)
    db.commit()
    db.refresh(new_post)
    return {"data": new_post}


@router.get("/loadstudent",response_model=List[Schemas.Stu])
def loadPosts(db: Session = Depends(get_db)):
    posts = db.query(Models.Student).all()
    print(posts)
    return posts


@router.get("/loadstudent/{name}")
def loadUser(name: str, db: Session = Depends(get_db)):
    post = db.query(Models.Student).filter(Models.Student.name == name).first()
    print(post)
    return {"data": post}


@router.delete("/deletestudent/{name}", status_code=status.HTTP_204_NO_CONTENT)
def deleteStudent(name: str, db: Session = Depends(get_db)):
    post = db.query(Models.Student).filter(Models.Student.name == name)
    if post.first() == None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given ID not found")
    post.delete()
    db.commit()
    return {"message": "user deleted"}
