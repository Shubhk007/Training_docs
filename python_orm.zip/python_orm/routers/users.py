from .. import utils
from fastapi import FastAPI, HTTPException, Response, Depends, status, APIRouter
from sqlalchemy.orm import Session
from typing import Optional, List

from .. import Models, Schemas
from .. database import engine, get_db

router = APIRouter(
    tags=["users"]
)

@router.post("/addUser", status_code=status.HTTP_201_CREATED, response_model=Schemas.UserOut)
def addUser(user: Schemas.UserCreate, db: Session = Depends(get_db)):
    new_user = Models.User(email=user.email, password=utils.hash(user.password))
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.get("/loadUser", response_model=List[Schemas.UserOut])
def loadPosts(db: Session = Depends(get_db)):
    posts = db.query(Models.User).all()
    print(posts)
    return posts